package com.saml.idp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IdpApplicationTests {

	@Test
	void contextLoads() {
	}

}
